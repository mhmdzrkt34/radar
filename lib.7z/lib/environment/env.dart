class ENV {

  ENV();




  String broker="test.mosquitto.org";

  int port=1883;

  String clientIdentifier="radar_client";
  String subscriptionTopic="/lazershoter";



  String subscriptionTopictwo="/score";

  String subscriptionTopicthree="/tankLosescore";




}